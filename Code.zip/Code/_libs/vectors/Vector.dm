

// BYOND 516 Compatibility: Renamed custom Vector class to CustomVector to avoid conflict with built-in /vector primitive
// The built-in vector type cannot be overridden or derived from in BYOND 516+
var/CustomVector/Vector = null

proc/dir2vector(dir)
	return new/CustomVector(
		((dir & EAST) > 0) - ((dir & WEST) > 0),
		((dir & NORTH) > 0) - ((dir & SOUTH) > 0),
		((dir & UP) > 0) - ((dir & DOWN) > 0))

// BYOND 516: Renamed custom vector type from 'vector' to 'CustomVector'
CustomVector
	var/_x
	var/_y
	var/_z
	// Direction constant instances
	var/CustomVector/zero
	var/CustomVector/north
	var/CustomVector/south
	var/CustomVector/east
	var/CustomVector/west
	var/CustomVector/up
	var/CustomVector/down

	proc/X()
		return _x

	proc/Y()
		return _y

	proc/Z()
		return _z

	proc/With(x = _x, y = _y, z = _z)
		return new/CustomVector(x, y, z)

	proc/Text(figures = 6)
		return text("vector([], [], [])",
			num2text(X(), figures),
			num2text(Y(), figures),
			num2text(Z(), figures))

	proc/operator~=(CustomVector/v)
		return \
			X() == v.X() && \
			Y() == v.Y() && \
			Z() == v.Z()

	proc/operator+(CustomVector/v)
		return new/CustomVector(
			X() + v.X(),
			Y() + v.Y(),
			Z() + v.Z())

	proc/operator-()
		if(length(args) > 0)
			return Subtract(args[1])
		else
			return Negate()

	proc/operator*(arg)
		if(isnum(arg))
			return Scale(arg)
		if(istype(arg, /CustomVector))
			return Multiply(arg)
		if(istype(arg, /matrix))
			return Transform(arg)
		CRASH("Undefined")

	proc/operator/(arg)
		if(isnum(arg))
			return Scale(1 / arg)
		if(istype(arg, /CustomVector))
			return Divide(arg)
		if(istype(arg, /matrix))
			return Transform(~arg)
		CRASH("Undefined")

	proc/Subtract(CustomVector/v)
		return new/CustomVector(
			X() - v.X(),
			Y() - v.Y(),
			Z() - v.Z())

	proc/Negate()
		return new/CustomVector(-X(), -Y(), -Z())

	proc/Scale(scalar)
		return new/CustomVector(
			X() * scalar,
			Y() * scalar,
			Z() * scalar)

	proc/Multiply(CustomVector/v)
		return new/CustomVector(
			X() * v.X(),
			Y() * v.Y(),
			Z() * v.Z())

	proc/Transform(matrix/matrix)
		return new/CustomVector(
			X() * matrix.a + Y() * matrix.b + matrix.c,
			X() * matrix.d + Y() * matrix.e + matrix.f,
			Z())

	proc/Divide(CustomVector/v)
		return new/CustomVector(
			X() / v.X(),
			Y() / v.Y(),
			Z() / v.Z())

	// BYOND 516: Renamed from Dot() to DotProduct() to avoid conflict with built-in methods
	proc/DotProduct(CustomVector/v)
		return \
			X() * v.X() + \
			Y() * v.Y() + \
			Z() * v.Z()

	// BYOND 516: Renamed from Cross() to CrossProduct() to avoid conflict with built-in methods
	proc/CrossProduct(CustomVector/v)
		return new/CustomVector(
			Y() * v.Z() - Z() * v.Y(),
			Z() * v.X() - X() * v.Z(),
			CrossZ(v))

	proc/CrossZ(CustomVector/v)
		return X() * v.Y() - Y() * v.X()

	proc/LengthSquared()
		return DotProduct(src)

	proc/Length()
		return sqrt(LengthSquared())

	proc/Direction()
		return src / Length()

	proc/HasDirection()
		return src ~! Vector.zero

	proc/DirectionOrZero()
		return HasDirection() ? Direction() : src

	proc/HasLength()
		return HasDirection()

	proc/Rotation(CustomVector/from = Vector.north)
		var/CustomVector/to_direction = Direction()
		var/CustomVector/from_direction = from.Direction()
		var/cos = to_direction.DotProduct(from_direction)
		var/sin = to_direction.CrossZ(from_direction)
		return matrix(cos, sin, 0, -sin, cos, 0)

	// BYOND 516: Renamed from Turn() to RotateByDegrees() to avoid conflict with built-in methods
	proc/RotateByDegrees(clockwise_degrees)
		return src * matrix(clockwise_degrees, MATRIX_ROTATE)

	proc/WithLength(length)
		return src * (length / Length())

	proc/WithLengthOrZero(length)
		return HasLength() ? WithLength(length) : src

	proc/ClampLength(upper)
		return DirectionOrZero() * min(Length(), upper)

	proc/ToDir()
		var/exact = ToExactDir()
		if(exact & (exact - 1))
			var/abs_x = abs(X())
			var/abs_y = abs(Y())
			if(abs_x >= abs_y * 2)
				return exact & (EAST | WEST)
			if(abs_y >= abs_x * 2)
				return exact & (NORTH | SOUTH)
		return exact

	proc/ToCardinalDir()
		var/exact = ToExactDir()
		if(exact & (exact - 1))
			var/abs_x = abs(X())
			var/abs_y = abs(Y())
			if(abs_x >= abs_y)
				return exact & (EAST | WEST)
			if(abs_y >= abs_x)
				return exact & (NORTH | SOUTH)
		return exact

	proc/ToExactDir()
		return \
			(X() == 0 ? 0 : X() > 0 ? EAST : WEST) | \
			(Y() == 0 ? 0 : Y() > 0 ? NORTH : SOUTH) | \
			(Z() == 0 ? 0 : Z() > 0 ? UP : DOWN)

	proc/Clamp(CustomVector/lower, CustomVector/upper)
		return new/CustomVector(
			clamp(X(), lower.X(), upper.X()), 
			clamp(Y(), lower.Y(), upper.Y()), 
			clamp(Z(), lower.Z(), upper.Z()))

	proc/DegreesTo(CustomVector/other)
		return -DegreesFrom(other)

	proc/DegreesFrom(CustomVector/other)
		var/CustomVector/direction = Direction()
		var/CustomVector/other_direction = other.Direction()
		var/cos = direction.DotProduct(other_direction)
		var/sin = direction.CrossZ(other_direction)
		return arctan(cos, sin)

	New(x = 0, y = 0, z = 0)
		..()
		_x = x
		_y = y
		_z = z
		// Initialize singleton and direction constants on first instantiation
		if(Vector == null)
			Vector = new/CustomVector(0, 0, 0)
			Vector.zero = new/CustomVector(0, 0, 0)
			Vector.north = new/CustomVector(0, 1, 0)
			Vector.south = new/CustomVector(0, -1, 0)
			Vector.east = new/CustomVector(1, 0, 0)
			Vector.west = new/CustomVector(-1, 0, 0)
			Vector.up = new/CustomVector(0, 0, 1)
			Vector.down = new/CustomVector(0, 0, -1)
