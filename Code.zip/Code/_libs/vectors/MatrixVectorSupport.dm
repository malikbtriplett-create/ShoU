

// BYOND 516 Compatibility: Updated to use CustomVector instead of built-in vector type
matrix
	Translate(x, y)
		if(istype(x, /CustomVector))
			var/CustomVector/vector = x
			return ..(vector.X(), vector.Y())
		return ..()

	Scale(x, y)
		if(istype(x, /CustomVector))
			var/CustomVector/vector = x
			return ..(vector.X(), vector.Y())
		return ..()
