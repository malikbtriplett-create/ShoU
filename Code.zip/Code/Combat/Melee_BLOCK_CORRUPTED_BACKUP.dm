//this means having really high speed decreases the damage you do per hit//actually hit them
	var/hit_landed = (prob(accuracy) || (ismob(target) && !target.CanMeleeDodge(src)))

	//to make dodge rate 100% so long as they have yellow bar
	//if(ismob(target) && target.CanMeleeDodge(src)) hit_landed = 0

    if(hit_landed)
        if(ismob(target) && target.IsBlocking())
            var/block_result = target.ResolveMeleeBlock(src, dmg, knockback)

            if(block_result == 2)
                Reset_melee()
                return

            if(block_result > 0)
                dmg = block_result
		Play_Melee_Sound(sound_range=10,origin=src,sound_file=pick(sounds),sound_volume=20)
		if(lunge_attacking) BigCrater(pos = target.base_loc(), minRangeFromOtherCraters = 3)

		if(ismob(target))
			if(knockback)
				if(prob(33)) Make_Shockwave(target, sw_icon_size=pick(128,256))
				if(target) Melee_Shockwave_Repel(target)
				target.Knockback(src, knockback, from_lunge=lunge_attacking)
				if(!target)
					Reset_melee()
					return
				combo_teleport(target)

			target.ApplyBleed(GetWeaponBleed() * 20)

			if(DoesWeaponStun() && prob(10)) target.ApplyStun()

			var/injury/tryInjure = new/injury/fracture/ribs
			target.TryInjure(tryInjure, GetWeaponFracture(), dmg, src)
			tryInjure = new/injury/fracture/left_arm
			target.TryInjure(tryInjure, GetWeaponFracture(), dmg, src)
			tryInjure = new/injury/fracture/right_arm
			target.TryInjure(tryInjure, GetWeaponFracture(), dmg, src)
			tryInjure = new/injury/fracture/left_leg
			target.TryInjure(tryInjure, GetWeaponFracture(), dmg, src)
			tryInjure = new/injury/fracture/right_leg
			target.TryInjure(tryInjure, GetWeaponFracture(), dmg, src)

			tryInjure = new/injury/laceration
			target.TryInjure(tryInjure, GetWeaponLacerate(), dmg, src)
			tryInjure = new/injury/bruising
			target.TryInjure(tryInjure, GetWeaponBruise(), dmg, src)
			tryInjure = new/injury/tortion
			target.TryInjure(tryInjure, GetWeaponTortion(), dmg, src)
			tryInjure = new/injury/internal_bleeding
			target.TryInjure(tryInjure, GetWeaponInternal(), dmg, src)

			target.TakeDamage(dmg, src)

		if(isobj(target))
			var/obj/o = target
			target.Health -= dmg
			if(target.Health<=0)
				if(!o.leaves_big_crater) Small_crater(o.loc)
				del(target)

		if(isturf(target))
			var/turf/t=target
			t.Health-=dmg
			if(t.Health<=0)
				t.Health=0
				t.Destroy()
	else
		last_combo_teleport=0
		target.last_combo_teleport=0
		target.MeleeAutoDodge(src)

		if(target.ultra_instinct)
			target.Flip()
			target.SafeTeleport(loc)
			step(src, dir, 32)
			if(prob(67))
				var/d = get_dir(target,src)
				d = turn(d, pick(45,-45))
				step(target, d, 32)
			target.dir = get_dir(target,src)

	if_target_is_npc_target_attacks_you(target)

mob/proc/ResolveMeleeBlock(mob/attacker, dmg = 0, knockback = 0)
    if(!blocking || !attacker) return 0

    // Speed controls the initial Perfect Block reaction window.
    // Holding Block does not continually refresh this window.
    var/perfect_window = 2 + round(Math.Max(GetStatMod("Spd"), 1) / 2)
    perfect_window = Math.Clamp(perfect_window, 2, 5)

    var/block_age = world.time - block_started_at

    if(block_started_at > 0 && block_age >= 0 && block_age <= perfect_window)
        block_started_at = 0

        // Perfect Block completely stops the melee attack.
        if(knockback > 0)
            attacker.Knockback(src, knockback)

        attacker.ApplyStun()

        return 2

    // Perfect Block window has expired.
    // This is now a normal sustained Block.
    block_started_at = 0

    // Normal melee Block uses Durability for mitigation.
    // Speed does not increase ordinary block toughness.
    var/block_reduction = GetStatMod("Dur")
    block_reduction = Math.Clamp(block_reduction / (block_reduction + 10), 0, 0.75)

    dmg *= (1 - block_reduction)

    return dmg

mob/proc/MeleeAutoDodge(mob/attacker)
	IncreaseKi(-6)

	Play_Melee_Sound(sound_range=10,origin = src,sound_file=pick('meleemiss1.ogg',\
		'meleemiss2.ogg','meleemiss3.ogg'),sound_volume=20)
	Dodge_animation()
	dir = get_dir(src, attacker)

mob/proc/TryMeleeInjuries()

mob/proc/CanMeleeDodge(mob/attacker)
	if(!client) return //quick dirty fix to stop dead bodies from dodging but it affects all npcs oh well tho
	if(KO) return

	if(!(get_dir(src, attacker) == dir)) return

	return 1

mob/proc/CanBlastDeflect(mob/attacker)
	if(!client) return //quick dirty fix to stop dead bodies from dodging but it affects all npcs oh well tho
	if(KO) return

	if(!(get_dir(src, attacker) == dir)) return

	return 1

mob/proc/Dodge_animation()

	flick('Zanzoken.dmi',src)
	return

	if(!dodge_gfx)
		flick('Zanzoken.dmi',src)
	else if(icon_state!="Dodge")
		icon_state="Dodge"
		spawn(2) if(icon_state=="Dodge") icon_state=""



proc/Play_Melee_Sound(sound_range=10,mob/origin,sound_file,sound_volume=20)
	if(!origin||!sound_range||!sound_file) return
	if(origin&&origin.client&&origin.client.inactivity>200) return

	player_view(sound_range,origin)<<sound(sound_file,volume=sound_volume)

mob/proc/Melee_Shockwave_Repel(mob/target) //target = the person you just attacked, so we can exclude them from the repel
	set waitfor=0
	if(!knockback_on) return //less annoying when trying to multi spar
	if(!client || !target.client)
		return //because npc fighting causing shockwaves was incredibly annoying when sim sparring in the gym
	if(current_area) for(var/mob/sw_mob in current_area.player_list)
		if(!sw_mob.Giving_Power && sw_mob != src && sw_mob != target && getdist(sw_mob,src) <= 4 && viewable(src,sw_mob))
			sw_mob.MeleeRepelMob(src, 1.5 * GetMeleeKnockbackDist(sw_mob))

mob/proc
	MeleeRepelMob(mob/m, kb_pow = 1)
		set waitfor=0
		Knockback(m, kb_pow)